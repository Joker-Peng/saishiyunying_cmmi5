<template>
  <div>创建组建请在上面嵌套一层文件夹 并为每个组建写下name</div>
</template>

<script>
export default {
  name: "demo",
};
</script>
