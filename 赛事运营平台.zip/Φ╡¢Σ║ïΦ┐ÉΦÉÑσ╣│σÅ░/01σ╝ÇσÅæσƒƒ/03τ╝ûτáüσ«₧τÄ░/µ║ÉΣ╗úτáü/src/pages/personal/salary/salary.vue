<template>
  <SalaryView />
</template>
<script>
import SalaryView from '../../plan/salaryView'
export default {
  name: 'Salary',
  components: {
    SalaryView
  },
}
</script>